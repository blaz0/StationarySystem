﻿namespace StationarySystem
{


    partial class sepdbDataSet
    {
    }
}

namespace StationarySystem.sepdbDataSetTableAdapters {
    
    
    public partial class usersTableAdapter {
    }
}
